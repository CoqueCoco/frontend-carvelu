import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

function Registro() {
  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [mensaje, setMensaje] = useState({ text: '', type: '' });
  const { register } = useContext(AuthContext);
  const navigate = useNavigate();

  const validarEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!nombre.trim() || !correo.trim() || !password || !confirmPassword) {
      setMensaje({ text: 'Completa todos los campos.', type: 'danger' });
      return;
    }

    if (password !== confirmPassword) {
      setMensaje({ text: 'Las contraseñas no coinciden.', type: 'danger' });
      return;
    }

    if (!validarEmail(correo)) {
      setMensaje({ text: 'Correo electrónico inválido.', type: 'danger' });
      return;
    }

    register(nombre, correo, password);
    setMensaje({ text: 'Registro exitoso. Redirigiendo...', type: 'success' });
    setTimeout(() => navigate('/login'), 1500);
  };

  return (
    <main className="container mt-5 pt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <h1 className="text-center mb-4">Registro de Usuario</h1>

          {mensaje.text && (
            <div className={`alert alert-${mensaje.type}`} role="alert">
              {mensaje.text}
            </div>
          )}

          <form onSubmit={handleSubmit} className="p-4 border rounded shadow-sm bg-light">
            <div className="mb-3">
              <label htmlFor="nombre" className="form-label">Nombre Completo:</label>
              <input type="text" id="nombre" className="form-control" value={nombre} onChange={(e) => setNombre(e.target.value)} required />
            </div>

            <div className="mb-3">
              <label htmlFor="correo" className="form-label">Correo Electrónico:</label>
              <input type="email" id="correo" className="form-control" value={correo} onChange={(e) => setCorreo(e.target.value)} required />
            </div>

            <div className="mb-3">
              <label htmlFor="password" className="form-label">Contraseña:</label>
              <input type="password" id="password" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>

            <div className="mb-3">
              <label htmlFor="confirmPassword" className="form-label">Confirmar Contraseña:</label>
              <input type="password" id="confirmPassword" className="form-control" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
            </div>

            <button type="submit" className="btn btn-success w-100">Registrarse</button>
          </form>
        </div>
      </div>
    </main>
  );
}

export default Registro;
