export const products = [
  {
    id: 1,
    nombre: "Lomo Vetado",
    categoria: "Carnes",
    price: 10990,
    originalPrice: 12990,
    img: "Lomo_Vetado.webp",
    isSale: true
  },
  {
    id: 2,
    nombre: "Huachalomo",
    categoria: "Carnes",
    price: 9990,
    originalPrice: 10990,
    img: "Huachalomo.webp",
    isSale: true
  },
  {
    id: 3,
    nombre: "Tomate Fresco",
    categoria: "Verduras",
    price: 1990,
    img: "tomate.jpg",
    isSale: false
  },
  {
    id: 4,
    nombre: "Lechuga Romana",
    categoria: "Verduras",
    price: 890,
    img: "lechuga.jpg",
    isSale: false
  }
];
