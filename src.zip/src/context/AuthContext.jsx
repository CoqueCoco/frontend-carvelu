import React, { createContext, useState } from "react";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem("user");
    return savedUser ? JSON.parse(savedUser) : null;
  });

  // Registrar usuario
  const register = (name, email, password) => {
    const newUser = { name, email, password };
    localStorage.setItem("registeredUser", JSON.stringify(newUser));
    setUser(newUser);
  };

  // Iniciar sesión
  const login = (email, password) => {
    const savedUser = JSON.parse(localStorage.getItem("registeredUser"));
    if (savedUser && savedUser.email === email && savedUser.password === password) {
      setUser(savedUser);
      localStorage.setItem("user", JSON.stringify(savedUser));
      return { success: true };
    } else {
      return { success: false, message: "Correo o contraseña incorrectos" };
    }
  };

  // Cerrar sesión
  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  return (
    <AuthContext.Provider value={{ user, register, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
