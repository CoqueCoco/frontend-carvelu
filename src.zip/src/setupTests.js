import '@testing-library/jest-dom'; 

// Este archivo se usa para configurar librerías de prueba (como @testing-library/jest-dom)
// que extienden las expectativas (ej. .toBeInTheDocument()).
// Karma y Jasmine tienen un archivo similar, aquí lo manejamos con Vitest.